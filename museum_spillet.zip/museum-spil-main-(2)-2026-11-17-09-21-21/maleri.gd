
extends MeshInstance3D

const BREDDE = 512
const HOEJDE = 512
const RADIUS = 18

var billede: Image
var tekstur: ImageTexture

func _ready():
	billede = Image.create(
		BREDDE, HOEJDE, false, Image.FORMAT_RGBA8
	)
	billede.fill(Color.WHITE)

	tekstur = ImageTexture.create_from_image(billede)

	var materiale = StandardMaterial3D.new()
	materiale.albedo_texture = tekstur
	materiale.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	materiale.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	materiale.cull_mode = BaseMaterial3D.CULL_DISABLED

	material_override = materiale


func mal_paa_sted(verdenspunkt: Vector3):
	var lokalt = to_local(verdenspunkt)

	var u = (lokalt.x + 1.0) / 2.0
	var v = (1.0 - lokalt.y) / 2.0

	if u < 0 or u > 1 or v < 0 or v > 1:
		return

	var px = int(u * (BREDDE - 1))
	var py = int(v * (HOEJDE - 1))

	# Lav en stor, ujævn splatter.
	var splat_radius = 32

	for y in range(maxi(0, py - splat_radius), mini(HOEJDE, py + splat_radius + 1)):
		for x in range(maxi(0, px - splat_radius), mini(BREDDE, px + splat_radius + 1)):
			var afstand = Vector2(x - px, y - py).length()
			var vinkel = atan2(y - py, x - px)

			# Ujævn kant, så pletten ligner maling.
			var kant = splat_radius * (
				1.0
				+ 0.18 * sin(vinkel * 5.0)
				+ 0.12 * cos(vinkel * 9.0)
			)

			if afstand <= kant:
				billede.set_pixel(x, y, Color(1, 1, 1, 0))

	# Små malerdråber rundt om pletten.
	for i in range(9):
		var vinkel = randf() * TAU
		var afstand = randf_range(35.0, 55.0)

		var droebe_x = px + int(cos(vinkel) * afstand)
		var droebe_y = py + int(sin(vinkel) * afstand)

		var droebe_radius = randi_range(3, 7)

		for y in range(maxi(0, droebe_y - droebe_radius), mini(HOEJDE, droebe_y + droebe_radius + 1)):
			for x in range(maxi(0, droebe_x - droebe_radius), mini(BREDDE, droebe_x + droebe_radius + 1)):
				if Vector2(x - droebe_x, y - droebe_y).length() <= droebe_radius:
					billede.set_pixel(x, y, Color(1, 1, 1, 0))

	tekstur.update(billede)
