
extends Area3D

const HASTIGHED = 25.0
const GRAVITY = 20.0

@onready var impact_sound: AudioStreamPlayer3D = $ImpactSound
@onready var kugle_mesh: MeshInstance3D = $MeshInstance3D

var hastighed: Vector3 = Vector3.ZERO
var har_ramt = false


func start(start_position: Vector3, flyve_retning: Vector3) -> void:
	global_position = start_position
	hastighed = flyve_retning.normalized() * HASTIGHED


func _physics_process(delta: float) -> void:
	if har_ramt:
		return

	# Tyngdekraft får kuglen til at falde
	hastighed.y -= GRAVITY * delta

	# Beregn kuglens næste position
	var fra = global_position
	var til = fra + hastighed * delta

	# Undersøg om kuglen rammer noget
	var forespoergsel = PhysicsRayQueryParameters3D.create(fra, til)
	var resultat = get_world_3d().direct_space_state.intersect_ray(forespoergsel)

	if not resultat.is_empty():
		var node = resultat["collider"]
		var ramte_maleri = false

		while node != null:
			if node.has_method("mal_paa_sted"):
				node.mal_paa_sted(resultat["position"])
				ramte_maleri = true
				break

			node = node.get_parent()

		if ramte_maleri:
			ram_maaleri()
		else:
			queue_free()

		return

	# Flyt kuglen
	global_position = til


func ram_maaleri() -> void:
	har_ramt = true

	# Skjul kuglen
	kugle_mesh.visible = false

	# Afspil lyd ved træffet
	impact_sound.play()

	# Vent på lyden, før kuglen slettes
	await impact_sound.finished

	queue_free()
